import pandas as pd

from impacther.reporting import build_safe_report


def test_safe_report_excludes_hidden_groups_and_exact_gender_counts():
    segments = pd.DataFrame(
        [
            {
                "work_category": "Dev · Mid",
                "category_method": "proxy_role_level",
                "role": "Dev",
                "level": "Mid",
                "women_n": 8,
                "men_n": 9,
                "sample_size_band": "10–19",
                "gap_pct": 6.0,
                "gap_ci_low": 1.0,
                "gap_ci_high": 10.0,
                "status": "OK",
            },
            {
                "work_category": "HR · Senior",
                "category_method": "proxy_role_level",
                "role": "HR",
                "level": "Senior",
                "women_n": pd.NA,
                "men_n": pd.NA,
                "sample_size_band": "ukryte",
                "gap_pct": float("nan"),
                "gap_ci_low": float("nan"),
                "gap_ci_high": float("nan"),
                "status": "Ukryte: mała grupa",
            },
        ]
    )

    report = build_safe_report(
        segments,
        data_label="demo",
        synthetic_demo=True,
        pay_scope="base + variable",
    )

    assert len(report) == 1
    assert "women_n" not in report.columns
    assert "men_n" not in report.columns
    assert report.iloc[0]["work_category"] == "Dev · Mid"
    assert bool(report.iloc[0]["legal_assessment"]) is False
