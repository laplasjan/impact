import pandas as pd

from impacther.directive import category_report, directive_overview, quartile_gender_share
from impacther.validation import validate_data


def _dataset():
    rows = []
    for i in range(12):
        gender = "woman" if i < 6 else "man"
        base = 9000 if gender == "woman" else 10000
        rows.append({
            "employee_id": str(i),
            "gender": gender,
            "salary_monthly_pln": base,
            "variable_pay_monthly_pln": 500 if gender == "woman" else 600,
            "fte": 1.0,
            "hours_weekly": 40,
            "role": "Dev",
            "level": "Mid",
            "work_category": "Engineering Mid",
        })
    return validate_data(pd.DataFrame(rows)).data


def test_directive_overview_and_category_screening():
    df = _dataset()
    overview = directive_overview(df, min_group_size=5)
    assert overview["total"]["status"] == "OK"
    report = category_report(df, min_group_size=5)
    assert len(report) == 1
    assert bool(report.iloc[0]["screening_5pct"]) is True
    assert report.iloc[0]["category_method"] == "provided_work_category"


def test_quartiles_return_gender_percentages():
    q = quartile_gender_share(_dataset(), min_group_size=5)
    assert len(q) == 4
    assert {"quartile", "women_pct", "men_pct"}.issubset(q.columns)
