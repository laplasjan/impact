import numpy as np

from impacther.demo_data import generate_demo_data, generate_heckman_demo_data
from impacther.heckman import run_heckman_two_step


def test_heckman_runs_on_synthetic_selection_demo():
    df = generate_heckman_demo_data(seed=7, n=700)
    result = run_heckman_two_step(df, bootstrap_reps=30, random_state=1)
    assert result.status == "OK"
    assert result.n_total > result.n_observed_pay > 30
    assert -50 < result.raw_gap_pct < 50
    assert -50 < result.adjusted_gap_pct < 50
    assert result.bootstrap_successes >= 20
    assert np.isfinite(result.ci_low_pct)
    assert np.isfinite(result.ci_high_pct)
    assert result.ci_low_pct <= result.adjusted_gap_pct <= result.ci_high_pct


def test_heckman_refuses_regular_payroll_without_selection_data():
    df = generate_demo_data(seed=42, n=100)
    result = run_heckman_two_step(df, bootstrap_reps=0)
    assert result.status == "NOT_READY"
    assert "Brak kolumn" in result.message
