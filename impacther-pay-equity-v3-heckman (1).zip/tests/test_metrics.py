import pandas as pd

from impacther.metrics import (
    action_recommendations,
    bootstrap_gap_ci,
    overall_metrics,
    pay_gap_percent,
    segmented_metrics,
)


def test_pay_gap_percent():
    assert round(pay_gap_percent(90, 100), 1) == 10.0


def test_small_group_hides_gap_and_exact_counts():
    df = pd.DataFrame(
        {
            "gender": ["woman", "woman", "man", "man"],
            "pay_fte_pln": [9000, 9100, 10000, 10100],
            "role": ["Dev"] * 4,
            "level": ["Mid"] * 4,
        }
    )
    result = segmented_metrics(df, min_group_size=3)
    assert result.iloc[0]["status"] == "Ukryte: mała grupa"
    assert pd.isna(result.iloc[0]["gap_pct"])
    assert pd.isna(result.iloc[0]["women_n"])
    assert pd.isna(result.iloc[0]["men_n"])
    assert result.iloc[0]["sample_size_band"] == "ukryte"


def test_overall_metrics_are_suppressed_for_small_gender_group():
    df = pd.DataFrame(
        {
            "gender": ["woman", "man", "man", "man"],
            "pay_fte_pln": [9000, 10000, 10000, 10000],
        }
    )
    result = overall_metrics(df, min_group_size=2)
    assert result["status"] == "Ukryte: mała grupa"
    assert pd.isna(result["gap_mean_pct"])


def test_bootstrap_ci_is_ordered_and_contains_point_estimate_in_simple_case():
    women = pd.Series([90, 91, 89, 90, 92, 88])
    men = pd.Series([100, 101, 99, 100, 102, 98])
    low, high = bootstrap_gap_ci(women, men, iterations=500, seed=1)
    point = pay_gap_percent(women.mean(), men.mean())
    assert low < high
    assert low <= point <= high


def test_five_percent_alert_is_not_triggered_when_women_average_is_higher():
    segments = pd.DataFrame(
        {
            "gap_pct": [-8.0],
            "status": ["OK"],
            "role": ["Dev"],
            "level": ["Mid"],
        }
    )
    recommendations = action_recommendations(segments, alert_threshold=5)
    assert "Nie ma grup przekraczających" in recommendations[0]
    assert "test prawny" not in recommendations[0].lower()
