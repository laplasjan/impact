import pandas as pd
import pytest

from impacther.reporting import build_benchmark_export


def test_benchmark_export_has_no_employee_or_gender_counts():
    categories = pd.DataFrame([{
        "work_category": "Dev Mid",
        "category_method": "provided_work_category",
        "sample_size_band": "20–49",
        "total_gap_pct": 6.0,
        "total_gap_ci_low": 2.0,
        "total_gap_ci_high": 10.0,
        "base_gap_pct": 5.0,
        "complementary_gap_pct": 8.0,
        "status": "OK",
    }])
    report = build_benchmark_export(
        categories,
        organization_alias="ORG1",
        reporting_period="2026",
        synthetic_demo=False,
        benchmark_use_authorized=True,
        pay_scope="test",
    )
    assert "employee_id" not in report.columns
    assert "women_n" not in report.columns
    assert "men_n" not in report.columns
    assert bool(report.iloc[0]["contains_employee_rows"]) is False


def test_benchmark_export_requires_authorization_for_real_data():
    with pytest.raises(PermissionError):
        build_benchmark_export(
            pd.DataFrame(),
            organization_alias="ORG1",
            reporting_period="2026",
            synthetic_demo=False,
            benchmark_use_authorized=False,
            pay_scope="test",
        )
