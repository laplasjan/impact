import numpy as np
import pandas as pd

from impacther.validation import validate_data


def test_validation_normalizes_fte_salary_and_variable_pay():
    df = pd.DataFrame(
        {
            "employee_id": ["1", "2"],
            "gender": ["woman", "man"],
            "salary_monthly_pln": [8000, 10000],
            "variable_pay_monthly_pln": [800, 0],
            "fte": [0.8, 1.0],
            "role": ["Dev", "Dev"],
            "level": ["Mid", "Mid"],
        }
    )
    result = validate_data(df)
    row = result.data.loc[result.data["employee_id"] == "1"].iloc[0]
    assert row["base_salary_fte_pln"] == 10000
    assert row["variable_pay_fte_pln"] == 1000
    assert row["pay_fte_pln"] == 11000
    assert result.variable_pay_included is True


def test_validation_rejects_blank_required_text_and_infinite_values():
    df = pd.DataFrame(
        {
            "employee_id": ["", "2", "3", "4", "5"],
            "gender": ["woman", "man", "woman", "man", "woman"],
            "salary_monthly_pln": [8000, np.inf, 9000, 9500, 10000],
            "fte": [1.0, 1.0, np.inf, 1.0, 1.0],
            "role": ["Dev", "Dev", "Dev", "", "Dev"],
            "level": ["Mid", "Mid", "Mid", "Mid", ""],
        }
    )
    result = validate_data(df)
    assert result.data.empty
    assert result.rejected_rows == 5


def test_blank_id_does_not_remove_valid_row_as_duplicate():
    df = pd.DataFrame(
        {
            "employee_id": ["", "", "OK-1"],
            "gender": ["woman", "man", "woman"],
            "salary_monthly_pln": [8000, 9000, 10000],
            "fte": [1.0, 1.0, 1.0],
            "role": ["Dev", "Dev", "Dev"],
            "level": ["Mid", "Mid", "Mid"],
        }
    )
    result = validate_data(df)
    assert result.data["employee_id"].tolist() == ["OK-1"]
