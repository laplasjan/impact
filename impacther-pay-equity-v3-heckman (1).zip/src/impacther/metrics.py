from __future__ import annotations

import numpy as np
import pandas as pd


def pay_gap_percent(women_pay: float, men_pay: float) -> float:
    """Descriptive gap: (men - women) / men * 100. Positive = women lower."""
    if not np.isfinite(men_pay) or men_pay <= 0 or not np.isfinite(women_pay):
        return float("nan")
    return (men_pay - women_pay) / men_pay * 100.0


def bootstrap_gap_ci(
    women: pd.Series,
    men: pd.Series,
    iterations: int = 1200,
    confidence: float = 0.95,
    seed: int = 42,
) -> tuple[float, float]:
    women_values = pd.to_numeric(women, errors="coerce").dropna().to_numpy(dtype=float)
    men_values = pd.to_numeric(men, errors="coerce").dropna().to_numpy(dtype=float)
    women_values = women_values[np.isfinite(women_values)]
    men_values = men_values[np.isfinite(men_values)]

    if len(women_values) < 2 or len(men_values) < 2:
        return float("nan"), float("nan")

    rng = np.random.default_rng(seed)
    women_samples = rng.choice(women_values, size=(iterations, len(women_values)), replace=True).mean(axis=1)
    men_samples = rng.choice(men_values, size=(iterations, len(men_values)), replace=True).mean(axis=1)
    valid = np.isfinite(men_samples) & (men_samples > 0)
    gaps = (men_samples[valid] - women_samples[valid]) / men_samples[valid] * 100.0
    if len(gaps) == 0:
        return float("nan"), float("nan")

    alpha = 1.0 - confidence
    low, high = np.quantile(gaps, [alpha / 2, 1 - alpha / 2])
    return float(low), float(high)


def _pay_column(df: pd.DataFrame) -> str:
    for candidate in ["total_pay_hourly_gross_pln", "pay_fte_pln", "salary_fte_pln"]:
        if candidate in df.columns:
            return candidate
    raise KeyError("Brak kolumny wynagrodzenia do analizy.")


def overall_metrics(df: pd.DataFrame, min_group_size: int = 5) -> dict:
    pay_col = _pay_column(df)
    women = df.loc[df["gender"] == "woman", pay_col]
    men = df.loc[df["gender"] == "man", pay_col]
    visible = len(women) >= min_group_size and len(men) >= min_group_size

    result = {
        "status": "OK" if visible else "Ukryte: mała grupa",
        "gap_mean_pct": float("nan"),
        "gap_median_pct": float("nan"),
        "gap_ci_low": float("nan"),
        "gap_ci_high": float("nan"),
    }
    if not visible:
        return result

    result["gap_mean_pct"] = float(pay_gap_percent(women.mean(), men.mean()))
    result["gap_median_pct"] = float(pay_gap_percent(women.median(), men.median()))
    result["gap_ci_low"], result["gap_ci_high"] = bootstrap_gap_ci(women, men)
    return result


def sample_size_band(total: int) -> str:
    if total < 10:
        return "<10"
    if total < 20:
        return "10–19"
    if total < 50:
        return "20–49"
    if total < 100:
        return "50–99"
    return "100+"


def segmented_metrics(
    df: pd.DataFrame,
    min_group_size: int = 5,
    group_column: str | None = None,
) -> pd.DataFrame:
    """Compare women and men inside a category; exact sex counts never need to leave this function."""
    pay_col = _pay_column(df)
    if group_column is None:
        group_column = "work_category_effective" if "work_category_effective" in df.columns else None

    if group_column and group_column in df.columns:
        group_keys = [group_column]
    else:
        group_keys = ["role", "level"]

    rows: list[dict] = []
    grouped = df.groupby(group_keys, dropna=False)
    for group_index, (key, group) in enumerate(grouped, start=1):
        if not isinstance(key, tuple):
            key = (key,)
        women = group.loc[group["gender"] == "woman", pay_col]
        men = group.loc[group["gender"] == "man", pay_col]
        visible = len(women) >= min_group_size and len(men) >= min_group_size

        if group_column and group_column in df.columns:
            category = str(key[0])
            role = str(group["role"].mode().iloc[0]) if "role" in group.columns and not group["role"].mode().empty else ""
            level = str(group["level"].mode().iloc[0]) if "level" in group.columns and not group["level"].mode().empty else ""
        else:
            role, level = map(str, key)
            category = f"{role} · {level}"

        base = {
            "work_category": category,
            "role": role,
            "level": level,
            "category_method": (
                "provided_work_category"
                if "category_method" in group.columns and (group["category_method"] == "provided_work_category").all()
                else "proxy_role_level"
            ),
        }

        if visible:
            gap = pay_gap_percent(women.mean(), men.mean())
            ci_low, ci_high = bootstrap_gap_ci(women, men, seed=42 + group_index)
            base.update(
                {
                    "women_n": int(len(women)),
                    "men_n": int(len(men)),
                    "sample_size_band": sample_size_band(len(group)),
                    "gap_pct": float(gap),
                    "gap_ci_low": ci_low,
                    "gap_ci_high": ci_high,
                    "status": "OK",
                }
            )
        else:
            base.update(
                {
                    "women_n": pd.NA,
                    "men_n": pd.NA,
                    "sample_size_band": "ukryte",
                    "gap_pct": float("nan"),
                    "gap_ci_low": float("nan"),
                    "gap_ci_high": float("nan"),
                    "status": "Ukryte: mała grupa",
                }
            )
        rows.append(base)

    result = pd.DataFrame(rows)
    if not result.empty:
        result = result.sort_values(by="gap_pct", ascending=False, na_position="last").reset_index(drop=True)
    return result


def action_recommendations(segment_df: pd.DataFrame, alert_threshold: float = 5.0) -> list[str]:
    """Screening prompts only. The threshold is not a legal compliance test."""
    visible = segment_df.dropna(subset=["gap_pct"]) if not segment_df.empty else segment_df
    if visible.empty:
        return ["Zbierz więcej danych w porównywalnych grupach przed interpretacją wyniku."]

    lower_for_women = visible.loc[visible["gap_pct"] >= alert_threshold]
    recommendations: list[str] = []
    if not lower_for_women.empty:
        recommendations.append(
            f"Sprawdź {len(lower_for_women)} grup(y), w których kobiety mają średnio niższe wynagrodzenie o co najmniej {alert_threshold:.0f}% — to screening, nie test prawny."
        )
    else:
        recommendations.append(
            "Nie ma grup przekraczających ustawiony próg screeningu; nadal sprawdź zasady poziomowania i wynagrodzeń."
        )
    recommendations.append("Zweryfikuj, czy kategorie naprawdę oznaczają tę samą pracę lub pracę o równej wartości.")
    recommendations.append("Sprawdź obiektywne kryteria oraz składniki: podstawa, premie, nadgodziny, dodatki i świadczenia.")
    recommendations.append("Powtórz pomiar po działaniach naprawczych i porównaj wynik w czasie.")
    return recommendations
