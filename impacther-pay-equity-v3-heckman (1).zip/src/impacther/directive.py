from __future__ import annotations

import numpy as np
import pandas as pd

from .metrics import bootstrap_gap_ci, pay_gap_percent, sample_size_band


def _gap_for(df: pd.DataFrame, column: str, min_group_size: int) -> dict:
    women = df.loc[df["gender"] == "woman", column]
    men = df.loc[df["gender"] == "man", column]
    if len(women) < min_group_size or len(men) < min_group_size:
        return {"mean_gap_pct": np.nan, "median_gap_pct": np.nan, "ci_low": np.nan, "ci_high": np.nan, "status": "Ukryte: mała grupa"}
    low, high = bootstrap_gap_ci(women, men)
    return {
        "mean_gap_pct": float(pay_gap_percent(women.mean(), men.mean())),
        "median_gap_pct": float(pay_gap_percent(women.median(), men.median())),
        "ci_low": low,
        "ci_high": high,
        "status": "OK",
    }


def directive_overview(df: pd.DataFrame, min_group_size: int = 5) -> dict:
    """Subset of metrics useful for Directive (EU) 2023/970 reporting logic.

    It is not a legal compliance certificate. It calculates descriptive metrics only.
    """
    total = _gap_for(df, "total_pay_hourly_gross_pln", min_group_size)
    complementary = _gap_for(df, "complementary_pay_hourly_gross_pln", min_group_size)

    women = df.loc[df["gender"] == "woman"]
    men = df.loc[df["gender"] == "man"]
    enough = len(women) >= min_group_size and len(men) >= min_group_size
    if enough:
        women_variable_share = float((women["complementary_pay_monthly_pln"] > 0).mean() * 100)
        men_variable_share = float((men["complementary_pay_monthly_pln"] > 0).mean() * 100)
    else:
        women_variable_share = np.nan
        men_variable_share = np.nan

    return {
        "total": total,
        "complementary": complementary,
        "women_receiving_complementary_pct": women_variable_share,
        "men_receiving_complementary_pct": men_variable_share,
    }


def category_report(df: pd.DataFrame, min_group_size: int = 5) -> pd.DataFrame:
    rows: list[dict] = []
    for index, (category, group) in enumerate(df.groupby("work_category_effective", dropna=False), start=1):
        women = group[group["gender"] == "woman"]
        men = group[group["gender"] == "man"]
        visible = len(women) >= min_group_size and len(men) >= min_group_size
        method = (
            "provided_work_category"
            if (group["category_method"] == "provided_work_category").all()
            else "proxy_role_level"
        )
        row = {
            "work_category": str(category),
            "category_method": method,
            "sample_size_band": sample_size_band(len(group)) if visible else "ukryte",
            "status": "OK" if visible else "Ukryte: mała grupa",
        }
        if not visible:
            row.update({
                "total_gap_pct": np.nan,
                "total_gap_ci_low": np.nan,
                "total_gap_ci_high": np.nan,
                "base_gap_pct": np.nan,
                "complementary_gap_pct": np.nan,
                "screening_5pct": False,
            })
            rows.append(row)
            continue

        total_gap = pay_gap_percent(
            women["total_pay_hourly_gross_pln"].mean(),
            men["total_pay_hourly_gross_pln"].mean(),
        )
        ci_low, ci_high = bootstrap_gap_ci(
            women["total_pay_hourly_gross_pln"],
            men["total_pay_hourly_gross_pln"],
            seed=100 + index,
        )
        base_gap = pay_gap_percent(
            women["base_pay_hourly_gross_pln"].mean(),
            men["base_pay_hourly_gross_pln"].mean(),
        )
        # Complementary pay can be zero for both groups, so guard the denominator.
        men_comp = men["complementary_pay_hourly_gross_pln"].mean()
        women_comp = women["complementary_pay_hourly_gross_pln"].mean()
        comp_gap = pay_gap_percent(women_comp, men_comp) if men_comp > 0 else np.nan
        row.update({
            "total_gap_pct": float(total_gap),
            "total_gap_ci_low": ci_low,
            "total_gap_ci_high": ci_high,
            "base_gap_pct": float(base_gap),
            "complementary_gap_pct": float(comp_gap) if np.isfinite(comp_gap) else np.nan,
            # Only the numerical first screen: women lower by >=5%.
            # Objective justification and 6-month remediation are not inferred by code.
            "screening_5pct": bool(total_gap >= 5.0),
        })
        rows.append(row)
    return pd.DataFrame(rows).sort_values("total_gap_pct", ascending=False, na_position="last").reset_index(drop=True)


def quartile_gender_share(df: pd.DataFrame, min_group_size: int = 5) -> pd.DataFrame:
    women_n = int((df["gender"] == "woman").sum())
    men_n = int((df["gender"] == "man").sum())
    if women_n < min_group_size or men_n < min_group_size or len(df) < 4:
        return pd.DataFrame(columns=["quartile", "women_pct", "men_pct"])

    ranked = df[["gender", "total_pay_hourly_gross_pln"]].copy()
    # Rank first to avoid qcut errors when many salaries are tied.
    ranked["quartile"] = pd.qcut(
        ranked["total_pay_hourly_gross_pln"].rank(method="first"),
        4,
        labels=["Q1 najniższy", "Q2", "Q3", "Q4 najwyższy"],
    )
    table = pd.crosstab(ranked["quartile"], ranked["gender"], normalize="index") * 100
    for column in ["woman", "man"]:
        if column not in table.columns:
            table[column] = 0.0
    return (
        table.reset_index()[["quartile", "woman", "man"]]
        .rename(columns={"woman": "women_pct", "man": "men_pct"})
    )
