from __future__ import annotations

import pandas as pd

SAFE_COLUMNS = [
    "work_category",
    "category_method",
    "sample_size_band",
    "gap_pct",
    "gap_ci_low",
    "gap_ci_high",
]

BENCHMARK_COLUMNS = [
    "work_category",
    "category_method",
    "sample_size_band",
    "total_gap_pct",
    "total_gap_ci_low",
    "total_gap_ci_high",
    "base_gap_pct",
    "complementary_gap_pct",
]


def build_safe_report(
    segments: pd.DataFrame,
    *,
    data_label: str,
    synthetic_demo: bool,
    pay_scope: str,
) -> pd.DataFrame:
    if segments.empty or "status" not in segments.columns:
        safe = pd.DataFrame(columns=SAFE_COLUMNS)
    else:
        visible = segments.loc[segments["status"] == "OK"].copy()
        safe = visible.reindex(columns=SAFE_COLUMNS).copy()

    safe.insert(0, "data_label", data_label)
    safe.insert(1, "synthetic_demo", synthetic_demo)
    safe.insert(2, "pay_scope", pay_scope)
    safe.insert(3, "generated_by", "ImpactHer Pay Equity MVP")
    safe.insert(4, "generated_metrics", True)
    safe.insert(5, "legal_assessment", False)
    safe.insert(6, "privacy_note", "Employee rows and exact sex-specific counts excluded")
    return safe


def build_benchmark_export(
    category_df: pd.DataFrame,
    *,
    organization_alias: str,
    reporting_period: str,
    synthetic_demo: bool,
    benchmark_use_authorized: bool,
    pay_scope: str,
    method_version: str = "impacther-v2",
) -> pd.DataFrame:
    """Aggregate-only export for a future consultant benchmark workflow.

    Authorization is a workflow gate, not proof of legal entitlement.
    """
    if not synthetic_demo and not benchmark_use_authorized:
        raise PermissionError("Benchmark export requires explicit confirmation of aggregation/reuse authorization.")

    if category_df.empty:
        safe = pd.DataFrame(columns=BENCHMARK_COLUMNS)
    else:
        visible = category_df.loc[category_df["status"] == "OK"].copy()
        safe = visible.reindex(columns=BENCHMARK_COLUMNS).copy()

    safe.insert(0, "organization_alias", organization_alias.strip() or "UNNAMED_ORG")
    safe.insert(1, "reporting_period", reporting_period.strip() or "unspecified")
    safe.insert(2, "synthetic_demo", bool(synthetic_demo))
    safe.insert(3, "pay_scope", pay_scope)
    safe.insert(4, "method_version", method_version)
    safe.insert(5, "benchmark_use_authorized", bool(benchmark_use_authorized or synthetic_demo))
    safe.insert(6, "contains_employee_rows", False)
    safe.insert(7, "contains_exact_gender_counts", False)
    safe.insert(8, "legal_assessment", False)
    return safe
