from __future__ import annotations

import numpy as np
import pandas as pd


def generate_demo_data(seed: int = 42, n: int = 360) -> pd.DataFrame:
    """Generate clearly labelled synthetic payroll data for the hackathon demo."""
    rng = np.random.default_rng(seed)
    roles = np.array(["Software Engineer", "Data Analyst", "Product Manager"])
    levels = np.array(["Junior", "Mid", "Senior"])
    base = {
        ("Software Engineer", "Junior"): 8500,
        ("Software Engineer", "Mid"): 13500,
        ("Software Engineer", "Senior"): 19500,
        ("Data Analyst", "Junior"): 7000,
        ("Data Analyst", "Mid"): 10500,
        ("Data Analyst", "Senior"): 15000,
        ("Product Manager", "Junior"): 9000,
        ("Product Manager", "Mid"): 14500,
        ("Product Manager", "Senior"): 20500,
    }

    records = []
    for i in range(n):
        gender = rng.choice(["woman", "man"], p=[0.48, 0.52])
        role = rng.choice(roles)
        level = rng.choice(levels, p=[0.30, 0.45, 0.25])
        fte = float(rng.choice([0.8, 1.0], p=[0.15, 0.85]))
        hours_weekly = 40.0 * fte

        factor = 1.0
        if gender == "woman":
            if role == "Software Engineer" and level == "Senior":
                factor = 0.91
            elif role == "Product Manager" and level == "Mid":
                factor = 0.92
            else:
                factor = 0.995

        full_time_base = base[(role, level)] * factor * rng.normal(1.0, 0.055)
        variable_share = {"Junior": 0.03, "Mid": 0.06, "Senior": 0.10}[level]
        variable = max(0.0, base[(role, level)] * variable_share * rng.normal(1.0, 0.25))
        overtime = max(0.0, rng.normal(220 if role != "Product Manager" else 80, 100))
        allowances = max(0.0, rng.normal(180, 60))
        benefits = max(0.0, rng.normal(250, 70))

        records.append({
            "employee_id": f"DEMO-{i+1:04d}",
            "gender": gender,
            "salary_monthly_pln": round(full_time_base * fte, 2),
            "variable_pay_monthly_pln": round(variable * fte, 2),
            "overtime_monthly_pln": round(overtime * fte, 2),
            "allowances_monthly_pln": round(allowances * fte, 2),
            "benefits_monthly_pln": round(benefits * fte, 2),
            "fte": fte,
            "hours_weekly": hours_weekly,
            "role": role,
            "level": level,
            # In real use this must be defined by the employer using objective gender-neutral criteria.
            "work_category": f"{role} | {level}",
            "data_source": "SYNTHETIC_DEMO",
            "is_synthetic": True,
            "generation_method": f"local_numpy_generator_seed_{seed}",
        })
    return pd.DataFrame(records)


def generate_heckman_demo_data(seed: int = 7, n: int = 900) -> pd.DataFrame:
    """Synthetic selection dataset solely to demonstrate the optional Heckman module."""
    rng = np.random.default_rng(seed)
    gender = rng.choice(["woman", "man"], size=n, p=[0.5, 0.5])
    is_woman = (gender == "woman").astype(float)
    experience = np.clip(rng.normal(7, 4, size=n), 0, 25)
    tenure = np.clip(experience * rng.uniform(0.2, 0.8, size=n), 0, 15)
    role = rng.choice(["Software Engineer", "Data Analyst"], size=n, p=[0.6, 0.4])
    level = np.where(experience < 3, "Junior", np.where(experience < 9, "Mid", "Senior"))

    # Synthetic exclusion variable: affects observation/selection only by construction.
    selection_exclusion = rng.normal(0, 1, size=n)
    eps_select = rng.normal(0, 1, size=n)
    latent = -0.25 - 0.35 * is_woman + 0.05 * experience + 0.55 * selection_exclusion + eps_select
    selected = (latent > 0).astype(int)

    # Correlated outcome disturbance creates selection bias for the demo.
    outcome_error = 0.45 * eps_select + rng.normal(0, 0.35, size=n)
    role_bonus = np.where(role == "Software Engineer", 0.13, 0.0)
    level_bonus = np.where(level == "Senior", 0.28, np.where(level == "Mid", 0.14, 0.0))
    log_hourly = 4.0 + 0.035 * experience + 0.01 * tenure + role_bonus + level_bonus - 0.055 * is_woman + outcome_error
    hourly = np.exp(log_hourly)
    hourly[selected == 0] = np.nan

    return pd.DataFrame({
        "selected_for_pay": selected,
        "hourly_pay_gross_pln": hourly,
        "gender": gender,
        "experience_years": experience,
        "tenure_years": tenure,
        "selection_exclusion": selection_exclusion,
        "role": role,
        "level": level,
        "data_source": "SYNTHETIC_HECKMAN_DEMO",
        "is_synthetic": True,
    })
