from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

REQUIRED_COLUMNS = {
    "employee_id",
    "gender",
    "salary_monthly_pln",
    "fte",
    "role",
    "level",
}

COMPLEMENTARY_PAY_COLUMNS = [
    "variable_pay_monthly_pln",
    "overtime_monthly_pln",
    "allowances_monthly_pln",
    "benefits_monthly_pln",
]

OPTIONAL_COLUMNS = {
    *COMPLEMENTARY_PAY_COLUMNS,
    "hours_weekly",
    "work_category",
}


@dataclass
class ValidationResult:
    data: pd.DataFrame
    issues: list[str]
    rejected_rows: int
    complementary_columns_present: list[str]
    work_category_complete: bool
    hours_source: str

    @property
    def variable_pay_included(self) -> bool:
        # Backwards-compatible property used by the older UI/tests.
        return "variable_pay_monthly_pln" in self.complementary_columns_present


def _blank(series: pd.Series) -> pd.Series:
    return series.isna() | series.astype("string").str.strip().eq("")


def _normalise_gender(series: pd.Series) -> pd.Series:
    mapping = {
        "female": "woman",
        "kobieta": "woman",
        "woman": "woman",
        "male": "man",
        "mężczyzna": "man",
        "mezczyzna": "man",
        "man": "man",
    }
    return series.astype("string").str.strip().str.lower().replace(mapping)


def validate_data(df: pd.DataFrame) -> ValidationResult:
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError("Brakuje wymaganych kolumn: " + ", ".join(sorted(missing)))

    clean = df.copy()
    issues: list[str] = []
    start_rows = len(clean)

    for column in ["employee_id", "gender", "role", "level"]:
        clean[column] = clean[column].astype("string").str.strip()
    clean["gender"] = _normalise_gender(clean["gender"])

    # Work category is the preferred grouping for directive-style reporting.
    work_category_present = "work_category" in clean.columns
    if work_category_present:
        clean["work_category"] = clean["work_category"].astype("string").str.strip()
    else:
        clean["work_category"] = pd.Series(pd.NA, index=clean.index, dtype="string")

    # Required numeric fields.
    clean["salary_monthly_pln"] = pd.to_numeric(clean["salary_monthly_pln"], errors="coerce")
    clean["fte"] = pd.to_numeric(clean["fte"], errors="coerce")

    # Complementary / variable pay components. Missing columns are treated as zero,
    # but we retain which components were genuinely present in the input.
    complementary_present = [c for c in COMPLEMENTARY_PAY_COLUMNS if c in clean.columns]
    for column in COMPLEMENTARY_PAY_COLUMNS:
        if column in clean.columns:
            clean[column] = pd.to_numeric(clean[column], errors="coerce")
        else:
            clean[column] = 0.0

    if not complementary_present:
        issues.append(
            "Brak składników uzupełniających/zmiennych: analiza wynagrodzenia obejmuje tylko płacę podstawową."
        )

    if "hours_weekly" in clean.columns:
        clean["hours_weekly"] = pd.to_numeric(clean["hours_weekly"], errors="coerce")
        hours_source = "provided"
    else:
        clean["hours_weekly"] = clean["fte"] * 40.0
        hours_source = "estimated_from_fte"
        issues.append("Brak hours_weekly: przyjęto 40 h/tydzień dla 1.0 FTE.")

    required_text_invalid = (
        _blank(clean["employee_id"])
        | _blank(clean["gender"])
        | _blank(clean["role"])
        | _blank(clean["level"])
    )

    salary = clean["salary_monthly_pln"]
    fte = clean["fte"]
    hours = clean["hours_weekly"]

    invalid_numeric = (
        salary.isna()
        | fte.isna()
        | hours.isna()
        | ~np.isfinite(salary)
        | ~np.isfinite(fte)
        | ~np.isfinite(hours)
        | (salary <= 0)
        | (fte <= 0)
        | (fte > 1.5)
        | (hours <= 0)
        | (hours > 80)
    )

    for column in COMPLEMENTARY_PAY_COLUMNS:
        values = clean[column]
        invalid_numeric |= values.isna() | ~np.isfinite(values) | (values < 0)

    invalid_mask = required_text_invalid | invalid_numeric
    invalid_rows = int(invalid_mask.sum())
    if invalid_rows:
        issues.append(f"Odrzucono niepoprawne lub puste wiersze: {invalid_rows}")
        clean = clean.loc[~invalid_mask].copy()

    allowed_gender = {"woman", "man"}
    unknown_gender = ~clean["gender"].isin(allowed_gender)
    if unknown_gender.any():
        count = int(unknown_gender.sum())
        issues.append(f"Odrzucono wiersze z nierozpoznaną płcią: {count}")
        clean = clean.loc[~unknown_gender].copy()

    # Duplicates only after blank IDs have been removed.
    duplicated = int(clean.duplicated(subset=["employee_id"], keep="first").sum())
    if duplicated:
        issues.append(f"Usunięto duplikaty ID: {duplicated}")
        clean = clean.drop_duplicates(subset=["employee_id"], keep="first").copy()

    # Category: use employer-defined work_category when supplied. Fallback is explicitly labelled proxy.
    work_category_complete = bool(
        work_category_present
        and len(clean) > 0
        and (~_blank(clean["work_category"])).all()
    )
    proxy = clean["role"].astype("string") + " · " + clean["level"].astype("string")
    clean["work_category_effective"] = clean["work_category"].where(
        ~_blank(clean["work_category"]), proxy
    )
    clean["category_method"] = np.where(
        ~_blank(clean["work_category"]), "provided_work_category", "proxy_role_level"
    )
    if not work_category_complete:
        issues.append(
            "Brak pełnej kolumny work_category: część/całość porównań używa proxy role + level, a nie formalnej kategorii pracy równej wartości."
        )

    clean["complementary_pay_monthly_pln"] = clean[COMPLEMENTARY_PAY_COLUMNS].sum(axis=1)
    clean["total_pay_monthly_pln"] = (
        clean["salary_monthly_pln"] + clean["complementary_pay_monthly_pln"]
    )

    # Gross annual and hourly equivalents. Using actual pay and actual weekly hours avoids
    # pretending that FTE alone is the legal definition of hourly pay.
    annual_hours = clean["hours_weekly"] * 52.0
    clean["base_pay_annual_gross_pln"] = clean["salary_monthly_pln"] * 12.0
    clean["complementary_pay_annual_gross_pln"] = clean["complementary_pay_monthly_pln"] * 12.0
    clean["total_pay_annual_gross_pln"] = clean["total_pay_monthly_pln"] * 12.0
    clean["base_pay_hourly_gross_pln"] = clean["base_pay_annual_gross_pln"] / annual_hours
    clean["complementary_pay_hourly_gross_pln"] = (
        clean["complementary_pay_annual_gross_pln"] / annual_hours
    )
    clean["total_pay_hourly_gross_pln"] = clean["total_pay_annual_gross_pln"] / annual_hours

    # Compatibility aliases for older modules.
    clean["base_salary_fte_pln"] = clean["salary_monthly_pln"] / clean["fte"]
    clean["variable_pay_fte_pln"] = clean["variable_pay_monthly_pln"] / clean["fte"]
    clean["pay_fte_pln"] = clean["total_pay_monthly_pln"] / clean["fte"]
    clean["salary_fte_pln"] = clean["pay_fte_pln"]

    finite_cols = [
        "base_pay_hourly_gross_pln",
        "complementary_pay_hourly_gross_pln",
        "total_pay_hourly_gross_pln",
    ]
    finite_mask = np.ones(len(clean), dtype=bool)
    for column in finite_cols:
        finite_mask &= np.isfinite(clean[column].to_numpy(dtype=float))
    if not finite_mask.all():
        count = int((~finite_mask).sum())
        issues.append(f"Odrzucono wiersze z nieskończonym wynagrodzeniem po normalizacji: {count}")
        clean = clean.loc[finite_mask].copy()

    rejected = start_rows - len(clean)
    if not issues:
        issues.append("Nie znaleziono krytycznych problemów z danymi.")

    return ValidationResult(
        data=clean.reset_index(drop=True),
        issues=issues,
        rejected_rows=rejected,
        complementary_columns_present=complementary_present,
        work_category_complete=work_category_complete,
        hours_source=hours_source,
    )
