from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy.stats import norm
import statsmodels.api as sm


@dataclass
class HeckmanResult:
    status: str
    raw_gap_pct: float = float("nan")
    adjusted_gap_pct: float = float("nan")
    ci_low_pct: float = float("nan")
    ci_high_pct: float = float("nan")
    woman_coefficient: float = float("nan")
    inverse_mills_coefficient: float = float("nan")
    n_total: int = 0
    n_observed_pay: int = 0
    bootstrap_successes: int = 0
    uncertainty_method: str = ""
    message: str = ""


def _design_matrix(df: pd.DataFrame, *, include_exclusion: bool) -> pd.DataFrame:
    required = ["is_woman", "experience_years", "tenure_years"]
    if include_exclusion:
        required.append("selection_exclusion")

    x = df[required].copy()
    categorical = [c for c in ["role", "level"] if c in df.columns]
    if categorical:
        dummies = pd.get_dummies(
            df[categorical].astype("string"),
            drop_first=True,
            dtype=float,
        )
        x = pd.concat([x, dummies], axis=1)

    x = x.apply(pd.to_numeric, errors="coerce").astype(float)
    return sm.add_constant(x, has_constant="add")


def _prepare_data(
    df: pd.DataFrame,
    *,
    selection_col: str,
    outcome_col: str,
) -> tuple[pd.DataFrame | None, HeckmanResult | None]:
    required = {
        selection_col,
        outcome_col,
        "gender",
        "experience_years",
        "tenure_years",
        "selection_exclusion",
    }
    missing = required - set(df.columns)
    if missing:
        return None, HeckmanResult(
            status="NOT_READY",
            message="Brak kolumn: " + ", ".join(sorted(missing)),
        )

    work = df.copy()
    work[selection_col] = pd.to_numeric(work[selection_col], errors="coerce")
    work[outcome_col] = pd.to_numeric(work[outcome_col], errors="coerce")
    for column in ["experience_years", "tenure_years", "selection_exclusion"]:
        work[column] = pd.to_numeric(work[column], errors="coerce")

    gender_clean = work["gender"].astype("string").str.strip().str.lower()
    work["is_woman"] = gender_clean.isin(["woman", "female", "kobieta", "f"]).astype(float)

    valid_selection = work[selection_col].isin([0, 1])
    predictors = work[["experience_years", "tenure_years", "selection_exclusion"]]
    finite_predictors = np.isfinite(predictors.to_numpy(dtype=float)).all(axis=1)
    nonblank_categories = np.ones(len(work), dtype=bool)
    for col in [c for c in ["role", "level"] if c in work.columns]:
        nonblank_categories &= work[col].astype("string").str.strip().ne("").to_numpy()

    work = work.loc[valid_selection & finite_predictors & nonblank_categories].copy()

    if work.empty or work[selection_col].nunique() < 2:
        return None, HeckmanResult(
            status="NOT_READY",
            n_total=len(work),
            message=(
                "Model selekcji wymaga zarówno obserwacji selected=1, jak i selected=0. "
                "Nie należy sztucznie tworzyć selected=0 w zwykłym payrollu."
            ),
        )

    observed = work[selection_col] == 1
    outcome_ok = (
        observed
        & work[outcome_col].notna()
        & np.isfinite(work[outcome_col])
        & (work[outcome_col] > 0)
    )
    if int(outcome_ok.sum()) < 30:
        return None, HeckmanResult(
            status="NOT_READY",
            n_total=len(work),
            n_observed_pay=int(outcome_ok.sum()),
            message="Za mało obserwowanych wynagrodzeń do stabilnego demo Heckmana.",
        )

    observed_work = work.loc[outcome_ok]
    if observed_work["is_woman"].nunique() < 2:
        return None, HeckmanResult(
            status="NOT_READY",
            n_total=len(work),
            n_observed_pay=int(outcome_ok.sum()),
            message="W obserwowanej próbie muszą występować kobiety i mężczyźni.",
        )

    return work, None


def _fit_core(
    work: pd.DataFrame,
    *,
    selection_col: str,
    outcome_col: str,
) -> tuple[float, float, float, int]:
    """Fit both Heckman stages and return raw gap, adjusted gap, IMR coefficient, n."""
    x_selection = _design_matrix(work, include_exclusion=True)
    y_selection = work[selection_col].astype(float)
    probit = sm.Probit(y_selection, x_selection).fit(disp=0, maxiter=200)

    linear = np.asarray(x_selection @ probit.params, dtype=float)
    cdf = np.clip(norm.cdf(linear), 1e-10, 1.0)
    work = work.copy()
    work["inverse_mills_ratio"] = norm.pdf(linear) / cdf

    outcome_ok = (
        (work[selection_col] == 1)
        & work[outcome_col].notna()
        & np.isfinite(work[outcome_col])
        & (work[outcome_col] > 0)
    )
    selected_work = work.loc[outcome_ok].copy()

    x_outcome = _design_matrix(selected_work, include_exclusion=False)
    x_outcome["inverse_mills_ratio"] = selected_work["inverse_mills_ratio"].to_numpy(dtype=float)
    y_outcome = np.log(selected_work[outcome_col].astype(float))
    ols = sm.OLS(y_outcome, x_outcome).fit(cov_type="HC3")

    beta = float(ols.params["is_woman"])
    adjusted_gap = (1.0 - np.exp(beta)) * 100.0

    women = selected_work.loc[selected_work["is_woman"] == 1, outcome_col].astype(float)
    men = selected_work.loc[selected_work["is_woman"] == 0, outcome_col].astype(float)
    raw_gap = ((men.mean() - women.mean()) / men.mean()) * 100.0

    return (
        float(raw_gap),
        float(adjusted_gap),
        float(ols.params["inverse_mills_ratio"]),
        int(outcome_ok.sum()),
    )


def run_heckman_two_step(
    df: pd.DataFrame,
    *,
    selection_col: str = "selected_for_pay",
    outcome_col: str = "hourly_pay_gross_pln",
    bootstrap_reps: int = 100,
    random_state: int = 42,
) -> HeckmanResult:
    """Classic two-step Heckman correction with row-bootstrap uncertainty.

    The model estimates:
    1. Probit(selection) using observed + non-observed cases and an exclusion variable.
    2. Log-wage equation among observed wages with the inverse Mills ratio.

    `selection_exclusion` must affect selection/observation but should not directly affect
    wages after controls. For the hackathon, the bundled demo satisfies this by construction.

    This is a research/screening module. It does not prove discrimination and should not be
    run on a payroll containing only employees with observed wages.
    """
    prepared, early_result = _prepare_data(
        df,
        selection_col=selection_col,
        outcome_col=outcome_col,
    )
    if early_result is not None:
        return early_result
    assert prepared is not None

    try:
        raw_gap, adjusted_gap, imr_coef, n_observed = _fit_core(
            prepared,
            selection_col=selection_col,
            outcome_col=outcome_col,
        )

        # Bootstrap the full two-step procedure. This propagates uncertainty from
        # BOTH the Probit selection stage and the wage equation, unlike a CI based
        # only on the second-stage OLS standard error.
        rng = np.random.default_rng(random_state)
        boot_gaps: list[float] = []
        reps = max(0, int(bootstrap_reps))

        for _ in range(reps):
            idx = rng.integers(0, len(prepared), size=len(prepared))
            sample = prepared.iloc[idx].reset_index(drop=True)

            if sample[selection_col].nunique() < 2 or sample["is_woman"].nunique() < 2:
                continue

            try:
                _, gap_b, _, n_b = _fit_core(
                    sample,
                    selection_col=selection_col,
                    outcome_col=outcome_col,
                )
                if n_b >= 30 and np.isfinite(gap_b):
                    boot_gaps.append(float(gap_b))
            except Exception:
                # Some bootstrap samples can have separation/singular designs.
                continue

        if len(boot_gaps) >= max(20, reps // 2) and reps > 0:
            ci_low, ci_high = np.percentile(boot_gaps, [2.5, 97.5])
            uncertainty_method = f"bootstrap całej procedury ({len(boot_gaps)}/{reps} udanych prób)"
        else:
            ci_low = float("nan")
            ci_high = float("nan")
            uncertainty_method = "brak stabilnego bootstrapu"

        # Refit once only to expose the female coefficient for diagnostics.
        x_selection = _design_matrix(prepared, include_exclusion=True)
        probit = sm.Probit(
            prepared[selection_col].astype(float), x_selection
        ).fit(disp=0, maxiter=200)
        linear = np.asarray(x_selection @ probit.params, dtype=float)
        cdf = np.clip(norm.cdf(linear), 1e-10, 1.0)
        diagnostic = prepared.copy()
        diagnostic["inverse_mills_ratio"] = norm.pdf(linear) / cdf
        outcome_ok = (
            (diagnostic[selection_col] == 1)
            & diagnostic[outcome_col].notna()
            & np.isfinite(diagnostic[outcome_col])
            & (diagnostic[outcome_col] > 0)
        )
        selected_work = diagnostic.loc[outcome_ok].copy()
        x_outcome = _design_matrix(selected_work, include_exclusion=False)
        x_outcome["inverse_mills_ratio"] = selected_work["inverse_mills_ratio"].to_numpy(dtype=float)
        ols = sm.OLS(
            np.log(selected_work[outcome_col].astype(float)), x_outcome
        ).fit(cov_type="HC3")

        delta_pp = adjusted_gap - raw_gap
        if delta_pp > 1:
            interpretation = (
                "Korekta selekcji ujawniła większą lukę niż prosta średnia — "
                "obserwowana próba mogła częściowo maskować nierówność."
            )
        elif delta_pp < -1:
            interpretation = (
                "Po korekcie selekcji luka jest mniejsza — część surowej różnicy "
                "mogła wynikać z tego, kto znalazł się w obserwowanej próbie."
            )
        else:
            interpretation = (
                "Korekta selekcji niewiele zmieniła wynik — w tym scenariuszu "
                "sam mechanizm obserwacji nie zmienia mocno wniosku."
            )

        return HeckmanResult(
            status="OK",
            raw_gap_pct=raw_gap,
            adjusted_gap_pct=adjusted_gap,
            ci_low_pct=float(ci_low),
            ci_high_pct=float(ci_high),
            woman_coefficient=float(ols.params["is_woman"]),
            inverse_mills_coefficient=imr_coef,
            n_total=len(prepared),
            n_observed_pay=n_observed,
            bootstrap_successes=len(boot_gaps),
            uncertainty_method=uncertainty_method,
            message=(
                "Dwustopniowy Heckman: Probit selekcji + OLS log-płacy z inverse Mills ratio. "
                + interpretation
            ),
        )
    except Exception as exc:
        return HeckmanResult(
            status="ERROR",
            n_total=len(prepared),
            message=f"Nie udało się oszacować modelu: {exc}",
        )
