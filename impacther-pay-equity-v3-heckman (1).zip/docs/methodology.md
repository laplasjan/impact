# Methodology

## 1. Dwa różne wyniki

### Niekorygowana luka ogólna

`gap = (mean_men - mean_women) / mean_men * 100%`

To opis całej próby. Może odzwierciedlać strukturę zatrudnienia, np. różny udział kobiet i mężczyzn na poziomach seniority. Nie powinna być samodzielnie używana jako ocena „równej płacy za porównywalną pracę”.

### Porównania grupowe
MVP porównuje osoby wewnątrz `role + level`. Jest to proste proxy do demonstracji, a nie prawna definicja kategorii pracy jednakowej lub o równej wartości.

## 2. Zakres płacy

Płaca jest normalizowana do pełnego etatu:

`pay_fte = (salary_monthly_pln + variable_pay_monthly_pln) / fte`

`variable_pay_monthly_pln` jest opcjonalne. Jeśli go brakuje, aplikacja jawnie oznacza analizę jako opartą tylko na podstawowej miesięcznej kwocie z pliku.

## 3. Niepewność

Dla widocznych wyników liczymy deterministyczny bootstrapowy 95% przedział niepewności dla różnicy średnich. Jest to miara stabilności wyniku w próbce, nie dowód przyczynowy.

## 4. Prywatność

- Wynik grupy jest ukrywany, gdy którakolwiek płeć ma mniej rekordów niż próg.
- UI i eksport nie pokazują dokładnych liczebności kobiet i mężczyzn.
- Eksport zawiera tylko grupy, które przeszły próg, i podaje jedynie przedział wielkości całej grupy.
- Próg liczebności nie gwarantuje anonimowości; realne wdrożenie wymaga osobnej oceny ryzyka i zasad agregacji.

## 5. Próg 5%

Domyślne 5% w aplikacji jest progiem alertu analitycznego. Nie jest automatycznym testem zgodności prawnej.

Dyrektywa (UE) 2023/970, art. 10, przewiduje wspólną ocenę wynagrodzeń przy łącznym spełnieniu określonych warunków, w tym różnicy średniego poziomu wynagrodzenia co najmniej 5% w kategorii pracowników, braku obiektywnego i neutralnego pod względem płci uzasadnienia oraz braku usunięcia nieuzasadnionej różnicy w ciągu sześciu miesięcy.

Źródło: https://eur-lex.europa.eu/legal-content/PL/ALL/?uri=CELEX:32023L0970

## 6. Heckman

Model Heckmana nie jest częścią MVP. Powinien zostać rozważony dopiero wtedy, gdy istnieje jasno zdefiniowany mechanizm selekcji do obserwowanej próby oraz zmienne pozwalające sensownie zidentyfikować model selekcji. Dodawanie go bez tych danych zwiększałoby pozorną złożoność, nie wiarygodność.
