# Sources

- Directive (EU) 2023/970 — EUR-Lex. Relevant concepts used in the MVP: work of equal value, objective gender-neutral criteria, reporting of mean/median gaps, complementary or variable components, quartile pay bands, category-level reporting and the joint pay assessment trigger.
- The application deliberately labels its 5% rule as screening only; it does not infer objective justification or remediation within six months.
