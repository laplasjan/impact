# AI / generation disclosure

- Kod MVP został przygotowany przy wsparciu generatywnego AI i powinien przejść review człowieka przed wdrożeniem.
- `data/demo_pay_gap.csv` oraz dane uruchamiane przez `generate_demo_data()` są syntetyczne.
- Demo selekcji dla Heckmana jest syntetyczne (`generate_heckman_demo_data`).
- Metryki, przedziały bootstrap i rekomendacje są generowane deterministycznie przez kod; rekomendacje są prostymi regułami, nie modelem AI.
- Aplikacja nie twierdzi, że syntetyczne wyniki opisują realny rynek.
