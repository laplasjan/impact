# ImpactHer Pay Equity — MVP v2

Prosty dashboard do wykrywania miejsc, w których warto rozpocząć audyt wynagrodzeń.

## Pierwszy look

1. Wczytaj CSV albo użyj jawnie syntetycznego demo.
2. Aplikacja odrzuca błędne rekordy i ukrywa małe grupy.
3. Pokazuje **niekorygowaną lukę ogólną** tylko jako kontekst.
4. Najważniejszy wynik to różnice **wewnątrz porównywalnych kategorii pracy**.
5. 5% to wyłącznie **screening**, nie automatyczny test prawny.

## Co poprawiono

- pełniejszy zakres płacy: podstawa + premie/zmienne + nadgodziny + dodatki + świadczenia,
- wynagrodzenie brutto roczne i godzinowe,
- `work_category` jako preferowana kategoria; `role + level` tylko jako jawne proxy,
- średnia, mediana, składniki zmienne, kwartyle i raport kategorii,
- bootstrap 95% CI,
- ukrywanie małych grup także w eksporcie,
- benchmark-ready eksport bez rekordów pracowników i dokładnych liczebności płci,
- bramka potwierdzająca uprawnienie do benchmarkingu,
- opcjonalny dwustopniowy Heckman na osobnym zbiorze selekcyjnym,
- jawne oznaczenie danych i treści generowanych.

## CSV — minimum

```text
employee_id, gender, salary_monthly_pln, fte, role, level
```

Lepszy tryb:

```text
work_category, hours_weekly,
variable_pay_monthly_pln, overtime_monthly_pln,
allowances_monthly_pln, benefits_monthly_pln
```

## Heckman

Heckman nie jest uruchamiany na zwykłym payrollu. Wymaga pełniejszego zbioru z obserwacjami `selected_for_pay=1` i `selected_for_pay=0` oraz wiarygodnej zmiennej `selection_exclusion`. Demo Heckmana jest w 100% syntetyczne.

## Uruchomienie

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Testy

```bash
PYTHONPATH=src pytest -q
```

## Ważne

To narzędzie analityczne, nie porada prawna ani automatyczny dowód dyskryminacji. Przed użyciem realnych danych trzeba ustalić podstawę przetwarzania, zasady retencji, dostęp, anonimizację/pseudonimizację i prawa do wtórnego wykorzystania benchmarków.
