from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from impacther.demo_data import generate_demo_data, generate_heckman_demo_data
from impacther.directive import category_report, directive_overview, quartile_gender_share
from impacther.heckman import run_heckman_two_step
from impacther.metrics import action_recommendations, overall_metrics, segmented_metrics
from impacther.reporting import build_benchmark_export, build_safe_report
from impacther.validation import validate_data

st.set_page_config(page_title="ImpactHer Pay Equity", page_icon="⚖️", layout="wide")

st.title("⚖️ ImpactHer Pay Equity")
st.caption("W 10 sekund: gdzie w porównywalnych grupach warto przyjrzeć się wynagrodzeniom?")
st.info(
    "DEMO HACKATHONOWE — dane przykładowe są syntetyczne. Wyniki są screeningiem do audytu, "
    "nie dowodem dyskryminacji ani automatycznym testem zgodności prawnej."
)

with st.sidebar:
    st.header("Dane")
    source = st.radio("Źródło", ["Użyj danych demo", "Wgraj CSV"])
    min_group = st.slider(
        "Minimalna liczebność każdej płci w grupie",
        5, 20, 8,
        help="Mniejsze grupy są ukrywane w UI i eksporcie. Sam próg nie gwarantuje anonimowości.",
    )
    alert_threshold = st.slider(
        "Próg screeningu [%]", 1, 15, 5,
        help="Próg analityczny. 5% nie jest samodzielnym testem prawnym.",
    )
    st.divider()
    st.caption("Minimum CSV")
    st.code("employee_id, gender, salary_monthly_pln, fte, role, level", language=None)
    st.caption("Lepszy tryb: work_category, hours_weekly + składniki uzupełniające/zmienne.")

if source == "Użyj danych demo":
    raw_df = generate_demo_data()
    data_label = "Syntetyczne dane demo"
    synthetic_demo = True
else:
    upload = st.file_uploader("Wgraj CSV", type=["csv"])
    if upload is None:
        st.warning("Wgraj CSV albo wybierz dane demo.")
        st.stop()
    if upload.size > 10 * 1024 * 1024:
        st.error("Plik jest większy niż 10 MB.")
        st.stop()
    try:
        raw_df = pd.read_csv(upload)
    except Exception as exc:
        st.error(f"Nie udało się odczytać CSV: {exc}")
        st.stop()
    data_label = "Dane wgrane przez użytkownika"
    synthetic_demo = False

try:
    validation = validate_data(raw_df)
except ValueError as exc:
    st.error(str(exc))
    st.stop()

clean = validation.data
if clean.empty:
    st.error("Po walidacji nie został żaden poprawny rekord.")
    st.stop()

overall = overall_metrics(clean, min_group_size=min_group)
segments = segmented_metrics(clean, min_group_size=min_group)
categories = category_report(clean, min_group_size=min_group)
visible = segments.loc[segments["status"] == "OK"].copy() if not segments.empty else segments
hidden_count = int((segments["status"] != "OK").sum()) if not segments.empty else 0
flagged_count = int((visible["gap_pct"] >= alert_threshold).sum()) if not visible.empty else 0

pay_scope = (
    "płaca podstawowa + " + ", ".join(validation.complementary_columns_present)
    if validation.complementary_columns_present
    else "tylko płaca podstawowa"
)
category_mode = "work_category" if validation.work_category_complete else "proxy role + level"

tab_dashboard, tab_eu, tab_benchmark, tab_research = st.tabs([
    "Dashboard", "Raport UE", "Benchmark", "Metodyka / Heckman"
])

with tab_dashboard:
    st.subheader("1. Pierwszy look")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Rekordy po walidacji", f"{len(clean)}")
    c2.metric("Porównywalne grupy", f"{len(visible)}")
    c3.metric("Grupy do sprawdzenia", f"{flagged_count}")
    c4.metric(
        "Niekorygowana luka ogólna",
        "ukryta" if overall["status"] != "OK" or pd.isna(overall["gap_mean_pct"]) else f'{overall["gap_mean_pct"]:.1f}%',
        help="Opis całej organizacji. Może wynikać ze struktury zatrudnienia; nie ocenia firmy samodzielnie.",
    )

    if validation.work_category_complete:
        st.success("Kategorie porównawcze: `work_category` z danych.")
    else:
        st.warning("Kategorie porównawcze: używamy uproszczenia `rola + poziom`. To nie jest pełna klasyfikacja pracy równej wartości.")

    st.caption("Najważniejszy wynik to porównanie wewnątrz kategorii, nie jedna liczba dla całej firmy.")

    st.subheader("2. Gdzie warto zajrzeć?")
    if visible.empty:
        st.warning("Za mało danych w porównywalnych grupach przy obecnym progu prywatności.")
    else:
        fig = px.bar(
            visible,
            x="work_category",
            y="gap_pct",
            labels={"work_category": "Kategoria pracy", "gap_pct": "Różnica średnich płac [%]"},
            title="Różnica wewnątrz porównywalnych kategorii",
        )
        fig.add_hline(y=0, line_width=1)
        fig.add_hline(y=alert_threshold, line_dash="dot", annotation_text=f"screening {alert_threshold}%")
        st.plotly_chart(fig, use_container_width=True)

        display = visible[["work_category", "sample_size_band", "gap_pct"]].copy()
        display["gap_pct"] = display["gap_pct"].round(1)
        display.columns = ["Kategoria", "Wielkość grupy", "Różnica %"]
        st.dataframe(display, use_container_width=True, hide_index=True)

    if hidden_count:
        st.caption(f"🔒 Ukryto {hidden_count} małych grup. Nie pokazujemy ich wyników ani dokładnych liczebności kobiet i mężczyzn.")

    st.subheader("3. Co zrobić dalej?")
    for item in action_recommendations(segments, alert_threshold=alert_threshold):
        st.write(f"• {item}")

    with st.expander("Niepewność — 95% przedział bootstrap"):
        if overall["status"] == "OK":
            st.write(f"**Luka ogólna:** {overall['gap_mean_pct']:.1f}% (95%: {overall['gap_ci_low']:.1f}% – {overall['gap_ci_high']:.1f}%)")
        if not visible.empty:
            ci = visible[["work_category", "gap_pct", "gap_ci_low", "gap_ci_high"]].copy()
            for col in ["gap_pct", "gap_ci_low", "gap_ci_high"]:
                ci[col] = ci[col].round(1)
            st.dataframe(ci, use_container_width=True, hide_index=True)

    safe_export = build_safe_report(
        segments,
        data_label=data_label,
        synthetic_demo=synthetic_demo,
        pay_scope=pay_scope,
    )
    st.download_button(
        "Pobierz bezpieczny raport CSV",
        data=safe_export.to_csv(index=False).encode("utf-8"),
        file_name="impacther_safe_report.csv",
        mime="text/csv",
    )

with tab_eu:
    st.subheader("Raportowanie — metryki zbliżone do logiki Dyrektywy (UE) 2023/970")
    st.caption("To warstwa analityczna, nie certyfikat zgodności. Prawo krajowe i wdrożenie dyrektywy trzeba weryfikować osobno.")
    overview = directive_overview(clean, min_group_size=min_group)
    total = overview["total"]
    comp = overview["complementary"]

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Średnia luka", "ukryta" if pd.isna(total["mean_gap_pct"]) else f'{total["mean_gap_pct"]:.1f}%')
    c2.metric("Mediana luki", "ukryta" if pd.isna(total["median_gap_pct"]) else f'{total["median_gap_pct"]:.1f}%')
    c3.metric("Luka składników dodatkowych", "ukryta" if pd.isna(comp["mean_gap_pct"]) else f'{comp["mean_gap_pct"]:.1f}%')
    c4.metric("Tryb kategorii", category_mode)

    st.markdown("**Kategorie pracy: podstawa + składniki uzupełniające/zmienne**")
    display_cat = categories.drop(columns=["status"], errors="ignore").copy()
    for col in ["total_gap_pct", "total_gap_ci_low", "total_gap_ci_high", "base_gap_pct", "complementary_gap_pct"]:
        if col in display_cat:
            display_cat[col] = display_cat[col].round(1)
    st.dataframe(display_cat, use_container_width=True, hide_index=True)
    st.caption("`screening_5pct=True` oznacza tylko pierwszy warunek liczbowy: kobiety mają średnio co najmniej 5% niższy poziom płacy w danej kategorii. Kod nie zgaduje obiektywnego uzasadnienia ani tego, czy różnicę usunięto w 6 miesięcy.")

    quartiles = quartile_gender_share(clean, min_group_size=min_group)
    st.markdown("**Udział kobiet i mężczyzn w kwartylach płacowych**")
    if quartiles.empty:
        st.write("Ukryte — za mało danych.")
    else:
        q = quartiles.copy()
        q[["women_pct", "men_pct"]] = q[["women_pct", "men_pct"]].round(1)
        st.dataframe(q, use_container_width=True, hide_index=True)

    st.markdown("**Udział osób otrzymujących składniki uzupełniające/zmienne**")
    if pd.isna(overview["women_receiving_complementary_pct"]):
        st.write("Ukryte — za mało danych.")
    else:
        st.write(f"Kobiety: **{overview['women_receiving_complementary_pct']:.1f}%** · Mężczyźni: **{overview['men_receiving_complementary_pct']:.1f}%**")

with tab_benchmark:
    st.subheader("Bezpieczny zalążek produktu dla konsultantów")
    st.caption("Eksportuje wyłącznie agregaty. Nie sprzedajemy rekordów pracowników ani dokładnych liczebności płci.")
    org_alias = st.text_input("Alias organizacji", value="DEMO_ORG" if synthetic_demo else "ORG_001")
    reporting_period = st.text_input("Okres raportowy", value="2026")
    authorized = st.checkbox(
        "Potwierdzam uprawnienie do agregacji i użycia danych do benchmarku",
        value=synthetic_demo,
        disabled=synthetic_demo,
        help="To bramka procesu, a nie automatyczne potwierdzenie zgodności prawnej.",
    )
    readiness = [
        ("Tylko agregaty", True),
        ("Ukrywanie małych grup", True),
        ("Kategoria pracy zdefiniowana w danych", validation.work_category_complete),
        ("Składniki uzupełniające/zmienne obecne", bool(validation.complementary_columns_present)),
        ("Uprawnienie do benchmarku", bool(authorized or synthetic_demo)),
    ]
    for label, ok in readiness:
        st.write(("✅" if ok else "⚠️") + " " + label)

    try:
        benchmark = build_benchmark_export(
            categories,
            organization_alias=org_alias,
            reporting_period=reporting_period,
            synthetic_demo=synthetic_demo,
            benchmark_use_authorized=bool(authorized),
            pay_scope=pay_scope,
        )
        st.download_button(
            "Pobierz benchmark-ready CSV",
            data=benchmark.to_csv(index=False).encode("utf-8"),
            file_name="impacther_benchmark_ready.csv",
            mime="text/csv",
        )
    except PermissionError as exc:
        st.warning(str(exc))

with tab_research:
    st.subheader("Metodyka i analiza zaawansowana")
    st.write("**Heckman nie działa na zwykłym payroll CSV.** Potrzebuje także osób, dla których płacy nie obserwujemy (`selected=0`) oraz wiarygodnej zmiennej wpływającej na selekcję, ale nie bezpośrednio na płacę.")
    st.caption("Dlatego jest tu osobno i nie komplikuje głównego pitchu.")

    use_heckman_demo = st.checkbox("Uruchom Heckmana na oznaczonych danych syntetycznych", value=False)
    if use_heckman_demo:
        heckman_df = generate_heckman_demo_data()
        with st.spinner("Liczenie korekty Heckmana i niepewności..."):
            result = run_heckman_two_step(heckman_df, bootstrap_reps=100, random_state=42)
        if result.status == "OK":
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Surowa luka w obserwowanej próbie", f"{result.raw_gap_pct:.1f}%")
            c2.metric("Luka po korekcie Heckmana", f"{result.adjusted_gap_pct:.1f}%")
            if pd.notna(result.ci_low_pct):
                c3.metric("95% przedział", f"{result.ci_low_pct:.1f}% – {result.ci_high_pct:.1f}%")
            else:
                c3.metric("95% przedział", "niestabilny")
            c4.metric("Obserwowane płace", f"{result.n_observed_pay}/{result.n_total}")

            st.success(result.message)
            st.caption(f"Niepewność: {result.uncertainty_method}.")
            st.info(
                "Jak to może pomagać kobietom? Jeżeli kobiety rzadziej trafiają do obserwowanej próby "
                "albo ich brakujące wynagrodzenia nie są losowe, sama średnia może zaniżać lub zawyżać problem. "
                "Heckman koryguje ten mechanizm, dzięki czemu HR dostaje lepszy sygnał, gdzie sprawdzić widełki, "
                "awanse, rekrutację i dostęp do lepiej płatnych ról. Model nie poprawia płac sam — poprawia jakość "
                "diagnozy, na podstawie której można podjąć działania."
            )
            st.warning(
                "To nadal nie jest dowód dyskryminacji. Wynik zależy od jakości zmiennej `selection_exclusion` "
                "i poprawności założeń modelu."
            )
        else:
            st.warning(result.message)

    with st.expander("Co wygenerowaliśmy?"):
        st.markdown(
            f"""
- **Dane główne:** {'TAK — syntetyczne, generator NumPy.' if synthetic_demo else 'NIE — dostarczone przez użytkownika.'}
- **Metryki, bootstrap, kwartyle:** generowane przez kod z aktualnych danych.
- **Rekomendacje:** proste reguły screeningu; nie model AI i nie porada prawna.
- **Heckman demo:** uruchamiany tylko na osobnym, jawnie syntetycznym zbiorze.
- **Kod MVP:** przygotowany przy wsparciu generatywnego AI; przed wdrożeniem wymaga review człowieka.
"""
        )

    with st.expander("Jakość danych"):
        st.write(f"**Źródło:** {data_label}")
        st.write(f"**Odrzucone wiersze:** {validation.rejected_rows}")
        st.write(f"**Godziny:** {'z danych' if validation.hours_source == 'provided' else 'oszacowane z FTE'}")
        for issue in validation.issues:
            st.write(f"• {issue}")
